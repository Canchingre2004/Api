import { Component } from '@angular/core';

@Component({
  selector: 'app-dbz',
  imports: [],
  templateUrl: './dbz.component.html',
  styleUrl: './dbz.component.css'
})
export class DbzComponent {

}
