import { Component } from '@angular/core';

@Component({
  selector: 'miapi-list-miapi',
  standalone: true, 
  imports: [],
  templateUrl: './list-miapi.component.html',
  styleUrl: './list-miapi.component.css'
})
export class ListMiapiComponent {

}
