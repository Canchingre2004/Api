import { Component } from '@angular/core';

@Component({
  selector: 'app-cocteles',
  imports: [],
  templateUrl: './cocteles.component.html',
  styleUrl: './cocteles.component.css'
})
export class CoctelesComponent {

}
